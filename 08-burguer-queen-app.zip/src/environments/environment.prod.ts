export const environment = {
  production: true,
  urlServer: 'http://192.168.0.24:3000/api/v2',
  urlServerImages: 'http://192.168.0.24:3000/images',
  stripe: {
    publishKey: 'pk_test_51MJkuYDwpaKiJEilq0vDek7WH3ruUejJohfwS2tqQhTeiZuV8kxneSD2L8NIsVCRzMUcRcilGxLFWXe8pRX96XEr00m2SVKbHl',
    secretKey: 'sk_test_51MJkuYDwpaKiJEil853rHx7ARzEEQ74cUqpBuFDpPwBoGiwIQsXQ0j2bGh5GfTgK14F26sUeFe1TKnSaBhXSGOHg00NNR9HCNe',
    customerId: 'cus_O5Y3BpUU9oSHa3'
  }
};
