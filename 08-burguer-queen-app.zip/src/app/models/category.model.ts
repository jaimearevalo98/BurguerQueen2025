export interface ICategory {
    _id?: string
    name: string
    img?: string
}