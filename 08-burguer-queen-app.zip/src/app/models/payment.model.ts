export interface IPayment {
    paymentIntentClientSecret: string
    ephemeralKey: string
    customer: string
}