export interface ITokenUser {
    accessToken: string
}