import { IProduct } from "./product.model"

export interface IQuantityProduct {
    quantity: number
    product: IProduct
}