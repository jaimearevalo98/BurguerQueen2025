import { ExtrasSelectedPipe } from './extras-selected.pipe';

describe('ExtrasSelectedPipe', () => {
  it('create an instance', () => {
    const pipe = new ExtrasSelectedPipe();
    expect(pipe).toBeTruthy();
  });
});
