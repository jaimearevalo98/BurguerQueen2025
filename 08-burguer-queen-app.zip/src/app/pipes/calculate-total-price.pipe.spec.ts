import { CalculateTotalPricePipe } from './calculate-total-price.pipe';

describe('CalculateTotalPricePipe', () => {
  it('create an instance', () => {
    const pipe = new CalculateTotalPricePipe();
    expect(pipe).toBeTruthy();
  });
});
